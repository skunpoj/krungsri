# เลขา AI — Export Pipeline (Claude Code + MCP)

ไปป์ไลน์ส่งออก **อัตโนมัติ** ต่อยอดจาก "เลขา AI" (Bonus 1) — แทนการพิมพ์ prompt ไปมาเอง
ระบบจะอ่านเอกสารที่วางไว้เอง แล้วสั่งทีมผู้ช่วย (subagents) ทำครบ 6 ขั้น → เขียนผลลง `./outputs/`

```
เอกสารเข้า (./inputs)  ──►  เลขา AI (orchestrator)  ──►  ทีมผู้ช่วย 5 ด้าน  ──►  ผลลัพธ์ (./outputs)
   .xlsx / .pdf              (Claude Code)              Task tool delegate         .md ครบทุกขั้น + สรุป
```

## ต้องมีก่อน
- Node.js 18+ และ **Claude Code**: `npm install -g @anthropic-ai/claude-code` แล้ว `claude` (ล็อกอินครั้งแรก)
- เอกสาร: ข้อมูลส่งออก (.xlsx/.csv) และ/หรือ Invoice/Packing List/Contract (.pdf)

## วิธีใช้

**แบบเปิดแชต (เห็นการทำงาน):**
```bash
cd export-secretary
claude            # เปิด Claude Code ในโฟลเดอร์นี้
/run-export       # สั่งเลขา AI รันครบ 6 ขั้น
```

**แบบอัตโนมัติ (headless — ไม่ต้องเปิดแชต):**
```bash
# 1) วางไฟล์ลงใน ./inputs/
# 2) รัน:
./run-pipeline.sh
# 3) ดูผลที่ ./outputs/
```

## ทำให้เป็น "pipeline" จริง (trigger อัตโนมัติ)
- **ตั้งเวลา (cron):** `*/30 * * * * /path/to/export-secretary/run-pipeline.sh`
- **เฝ้าโฟลเดอร์:** ใช้ `inotifywait`/`fswatch` รัน `run-pipeline.sh` เมื่อมีไฟล์ใหม่ตกลง `./inputs/`
- **อีเมล/แชต:** เพิ่ม MCP server (เช่น Gmail/Slack) ใน `.mcp.json` ให้เลขา AI ส่ง `7-summary.md` ออกเมื่อเสร็จ

## โครงสร้าง
```
export-secretary/
├── CLAUDE.md                  # บทบาทเลขา AI + กติกางาน
├── .claude/agents/            # ทีมผู้ช่วย 5 ด้าน (subagents)
│   ├── market-scout.md        #  หาตลาด + ผู้ซื้อ
│   ├── tariff-analyst.md      #  ภาษี + landed cost
│   ├── doc-reader.md          #  อ่าน/สกัดเอกสาร
│   ├── doc-drafter.md         #  ร่าง Invoice + Packing List
│   └── compliance-checker.md  #  ตรวจสอดคล้อง + กฎปลายทาง
├── .claude/commands/run-export.md   # /run-export (orchestrator)
├── .mcp.json                  # MCP: filesystem (เพิ่ม Gmail/Slack/ฯลฯ ได้)
├── run-pipeline.sh            # รัน headless
├── inputs/                    # วางไฟล์ที่นี่
└── outputs/                   # ผลลัพธ์ที่นี่ (1-market … 7-summary)
```

## เชื่อมกับเด็ค
- **Bonus 1 (เลขา AI)** = แนวคิดนี้ · ใช้ **Pixel Agents** (VS Code) เห็น subagents เป็นตัวละครตอนรัน `claude` แบบเปิดแชต
- **Bonus 2** = เวอร์ชันทำเอง (พิมพ์ทีละขั้น) · ไปป์ไลน์นี้ = เวอร์ชันอัตโนมัติเต็มรูปแบบ

## ข้อควรระวัง
- เอกสารที่ได้เป็น **ร่าง** — ต้องคนตรวจ + ลงนาม + ยื่นเอง
- ตัวเลขภาษี/กฎปลายทาง ตรวจกับแหล่งทางการ (CBP/USTR/กรมศุลฯ) ก่อนใช้จริง
- `acceptEdits` ให้เขียนไฟล์ได้อัตโนมัติ — ถ้าจะรันไร้คนดูเต็มที่ ควรรันใน VM/แซนด์บ็อกซ์ และอย่าใช้ `--dangerously-skip-permissions` บนเครื่องที่มีข้อมูลสำคัญ

## Loop Engineering (ทำให้เป็นลูปอัตโนมัติอย่างปลอดภัย)
ไปป์ไลน์นี้คือ "ลูปชั้นนอก" ที่ครอบเลขา AI — `run-pipeline.sh` + cron/เฝ้าโฟลเดอร์ = ลูปที่ป้อนงานให้ AI ทำเองต่อเนื่อง
ก่อนปล่อยรันเองไร้คนดู ให้ยึด 5 หลักการ:
1. ตั้งเป้าหมายลูปให้ชัด + เช็กว่า AI เข้าใจตรงกัน
2. มีกลไกประเมิน — ให้รู้ว่าเมื่อไรวนต่อ/หยุด
3. มีจุดให้คนแทรก (human-in-the-loop) — รายงานสถานะ + สั่งหยุดได้
4. เงื่อนไขหยุดชัด — ถึงเป้า หรือเกินเวลา/งบ
5. ทดสอบลูปสั้นๆ 2–3 รอบก่อนปล่อยจริง

**กันบิลบานปลาย:** เอเจนต์กินโทเคน 10–100× ของแชตทั่วไป — ตั้งเพดานงบ/จำนวนรอบเสมอ, เริ่มที่ความถี่ต่ำ (เช่น cron ทุก 30–60 นาที ไม่ใช่ทุกวินาที), และทดสอบใน VM/แซนด์บ็อกซ์ก่อน
