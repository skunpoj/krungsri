#!/usr/bin/env bash
# เลขา AI — รันไปป์ไลน์ส่งออกแบบ headless (ไม่ต้องเปิดแชต)
# วิธีใช้: วางไฟล์ลงใน ./inputs/ แล้วรัน ./run-pipeline.sh
set -euo pipefail
cd "$(dirname "$0")"

if [ -z "$(ls -A ./inputs 2>/dev/null | grep -v '.gitkeep')" ]; then
  echo "⚠️  ไม่พบไฟล์ใน ./inputs/ — วางไฟล์ข้อมูลส่งออก/เอกสารก่อน"
  exit 1
fi

echo "▶ เลขา AI กำลังรันไปป์ไลน์..."
# acceptEdits = ให้เขียนไฟล์ผลลัพธ์ได้โดยไม่ต้องกดยืนยันทีละครั้ง (ปลอดภัยกว่า bypass)
claude -p "/run-export" --permission-mode acceptEdits

echo "✅ เสร็จแล้ว — ดูผลที่ ./outputs/"
